<?php require_once("header.php");?>

    <!--<div class="site-section site-section-sm pb-0">
      <div class="container">
        <div class="row">
          <form class="form-search col-md-12" style="margin-top: -100px;">
            <div class="row  align-items-end">
              <div class="col-md-3">
                <label for="list-types">Listing Types</label>
                <div class="select-wrap">
                  <span class="icon icon-arrow_drop_down"></span>
                  <select name="list-types" id="list-types" class="form-control d-block rounded-0">
                    <option value="">Condo</option>
                    <option value="">Commercial Building</option>
                    <option value="">Land Property</option>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <label for="offer-types">Offer Type</label>
                <div class="select-wrap">
                  <span class="icon icon-arrow_drop_down"></span>
                  <select name="offer-types" id="offer-types" class="form-control d-block rounded-0">
                    <option value="">For Sale</option>
                    <option value="">For Rent</option>
                    <option value="">For Lease</option>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <label for="select-city">Select City</label>
                <div class="select-wrap">
                  <span class="icon icon-arrow_drop_down"></span>
                  <select name="select-city" id="select-city" class="form-control d-block rounded-0">
                    <option value="">New York</option>
                    <option value="">Brooklyn</option>
                    <option value="">London</option>
                    <option value="">Japan</option>
                    <option value="">Philippines</option>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <input type="submit" class="btn btn-success text-white btn-block rounded-0" value="Search">
              </div>
            </div>
          </form>
        </div>  

        <div class="row">
          <div class="col-md-12">
            <div class="view-options bg-white py-3 px-3 d-md-flex align-items-center">
              <div class="mr-auto">
                <a href="index.html" class="icon-view view-module active"><span class="icon-view_module"></span></a>
                <a href="view-list.html" class="icon-view view-list"><span class="icon-view_list"></span></a>
                
              </div>
              <div class="ml-auto d-flex align-items-center">
                <div>
                  <a href="#" class="view-list px-3 border-right active">All</a>
                  <a href="#" class="view-list px-3 border-right">Rent</a>
                  <a href="#" class="view-list px-3">Sale</a>
                </div>


                <div class="select-wrap">
                  <span class="icon icon-arrow_drop_down"></span>
                  <select class="form-control form-control-sm d-block rounded-0">
                    <option value="">Sort by</option>
                    <option value="">Price Ascending</option>
                    <option value="">Price Descending</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
       
      </div>
    </div>-->

    

    <div class="site-section site-section-sm bg-light">
      <div class="container">

      <h2 class="mb-0"><a href="index.php" style="color: black;"><strong>Juegos Inflables<span class="text-danger">.</span></strong></a></h2>
      <h2 style="color: #f9f9f9;">arriendo de juegos inflables la florida</h2>
      <h2 style="color: #f9f9f9;">arriendo de juegos inflables la reina</h2>
      
        <div class="row mb-5">
          <div class="col-md-4 col-lg-4 mb-4">
            <div class="property-entry h-100">
              <a href="dobletobogan.php" class="property-thumbnail">
                <!--<div class="offer-type-wrap">
                  <span class="offer-type bg-danger">Sale</span>
                  <span class="offer-type bg-success">Rent</span>
                </div>-->
                <img src="images/web6.jpg" alt="Image" class="img-fluid">
              </a>
              <div class="p-4 property-body">
                <!--<a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>-->
                <h2 class="property-title"><a href="dobletobogan.php">Doble Tobogan</a></h2>
                <strong class="property-price text-primary mb-3 d-block text-success">$ 50.000</strong>
                <ul class="property-specs-wrap mb-3 mb-lg-0">
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Medidas</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">
                    <strong>largo:</strong> 7 m.
                    <strong>ancho:</strong> 3.5 m.
                    <strong>alto:</strong> 4.5 m.    
                    </span>
                    
                  </li>
                  <br>
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Edad</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">3<sup>+</sup></span>
                    
                  </li>
                </ul>

              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <div class="property-entry h-100">
              <a href="tobogan.php" class="property-thumbnail">
                <!--<div class="offer-type-wrap">
                  <span class="offer-type bg-danger">Sale</span>
                  <span class="offer-type bg-success">Rent</span>
                </div>-->
                <img src="images/web2.jpg" alt="Image" class="img-fluid">
              </a>
              <div class="p-4 property-body">
                <!--<a href="#" class="property-favorite active"><span class="icon-heart-o"></span></a>-->
                <h2 class="property-title"><a href="tobogan.php">Tobogan</a></h2>
                <strong class="property-price text-primary mb-3 d-block text-success">$ 40.000</strong>
                <ul class="property-specs-wrap mb-3 mb-lg-0">
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Medidas</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">
                    <strong>largo:</strong> 4 m.
                    <strong>ancho:</strong> 3.5 m.
                    <strong>alto:</strong> 3.5 m.</strong>        
                    </span>
                    
                  </li>
                  <br>
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Edad</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">3<sup>+</sup></span>
                    
                  </li>
                </ul>

              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <div class="property-entry h-100">
              <a href="escalada.php" class="property-thumbnail">
                <!--<div class="offer-type-wrap">
                  <span class="offer-type bg-info">Lease</span>
                </div>-->
                <img src="images/web3.jpg" alt="Image" class="img-fluid">
              </a>
              <div class="p-4 property-body">
                <!--<a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>-->
                <h2 class="property-title"><a href="escalada.php">Escalada</a></h2>
                <strong class="property-price text-primary mb-3 d-block text-success">$ 30.000</strong>
                <ul class="property-specs-wrap mb-3 mb-lg-0">
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Medidas</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">
                    <strong>largo:</strong> 4 m.
                    <strong>ancho:</strong> 4 m.
                    <strong>alto:</strong> 3 m.
                        
                    </span>
                    
                  </li>
                  <br>
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Edad</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">de 3 a 5 años.</span>
                    
                  </li>
                </ul>

              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <div class="property-entry h-100">
              <a href="multiproposito.php" class="property-thumbnail">
                <!--<div class="offer-type-wrap">
                  <span class="offer-type bg-danger">Sale</span>
                  <span class="offer-type bg-success">Rent</span>
                </div>-->
                <img src="images/web4.jpg" alt="Image" class="img-fluid">
              </a>
              <div class="p-4 property-body">
                <!--<a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>-->
                <h2 class="property-title"><a href="multiproposito.php">Multiproposito</a></h2>
                <strong class="property-price text-primary mb-3 d-block text-success">$30.000</strong>
                <ul class="property-specs-wrap mb-3 mb-lg-0">
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Medidas</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">
                    <strong>largo:</strong> 4 m.
                    <strong>ancho:</strong> 3 m.
                    <strong>alto:</strong> 2.5 m.
                  
                        
                    </span>
                    
                  </li>
                  <br>
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Edad</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">de 3 a 5 años.</span>
                    
                  </li>
                </ul>

              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <div class="property-entry h-100">
              <a href="plazablanda.php" class="property-thumbnail">
                <!--<div class="offer-type-wrap">
                  <span class="offer-type bg-danger">Sale</span>
                  <span class="offer-type bg-success">Rent</span>
                </div>-->
                <img src="images/web5.jpg" alt="Image" class="img-fluid">
              </a>
              <div class="p-4 property-body">
                <!--<a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>-->
                <h2 class="property-title"><a href="plazablanda.php">Plaza Blanda</a></h2>
                <strong class="property-price text-primary mb-3 d-block text-success">$ 40.000</strong>
                <ul class="property-specs-wrap mb-3 mb-lg-0">
                
                  <li>
                    <span class="property-specs">Edad</span>
                    <span class="property-specs-number">desde 1 hasta 3 años</span>
                    
                  </li>
                </ul>

              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-4">
            <div class="property-entry h-100">
              <a href="minitobogan.php" class="property-thumbnail">
                <!--<div class="offer-type-wrap">
                  <span class="offer-type bg-info">Lease</span>
                </div>-->
                <img src="images/web7.jpg" alt="Image" class="img-fluid">
              </a>
              <div class="p-4 property-body">
                <!--<a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>-->
                <h2 class="property-title"><a href="minitobogan.php">Mini Tobogan</a></h2>
                <strong class="property-price text-primary mb-3 d-block text-success">$ 25.000 / $ 32.000 *</strong><span style="color: green"> *Con pelotas</span>
                <br>
                <br>
                <ul class="property-specs-wrap mb-3 mb-lg-0">
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Medidas</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">
                    <strong>largo:</strong> 3.5 m.
                    <strong>ancho:</strong> 3 m.
                    <strong>alto:</strong> 3 m.
                    
                  
                        
                    </span>
                    
                  </li>
                  <br>
                  <li>
                    <span class="property-specs" style="font-size: 12px;"><strong>Edad</strong></span>
                    <span class="property-specs-number" style="font-size: 14px;">de 1 a 2 años.</span>
                    
                  </li>
                </ul>

              </div>
            </div>
          </div>

        <!--</div>
        <div class="row">
          <div class="col-md-12 text-center">
            <div class="site-pagination">
              <a href="#" class="active">1</a>
              <a href="#">2</a>
              <a href="#">3</a>
              <a href="#">4</a>
              <a href="#">5</a>
              <span>...</span>
              <a href="#">10</a>
            </div>
          </div>  
        </div>-->
        
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 text-center">
            <div class="site-section-title">
              <h2>Por qué Eligirnos?</h2>
            </div>
            <p>Trabajamos con transparencia, confianza y empatía. 
                  Tratamos a cada cliente como si fuera el único, sus celebraciones son importantes para nosotros. 
                  Contamos con diferentes juegos para abastecer la diversión desde el primer añito hasta los 12 años.</p>
          </div>
        </div>
        <br>
        <br>
        <br>

        <div class="row">
          <div class="col-6 ">
            <a class="service text-center">
            <img src="images/icons/apreton-de-manos.png" alt="Image">
              <h2 class="service-heading">Compromiso</h2>
              <p>Nos comprometemos realmente con nuestros clientes para dar el mejor servicio, dando información clara y oportuna del servicio requerido. </p>
            </a>
          </div>
          <div class="col-6">
            <a class="service text-center">
              <img src="images/icons/puntual.png" alt="Image">
              <h2 class="service-heading">Puntualidad</h2>
              <p>Sabemos que para tus eventos la puntualidad es primordial, trabajamos comunicándonos con el cliente para coordinar horarios de instalación, así cuando los invitados lleguen, este todo listo y comiences la celebración tranquilamente.</p>
              
            </a>
          </div>
        </div>
      </div>
    </div>

    <!--<div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <div class="site-section-title">
              <h2>Recent Blog</h2>
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis maiores quisquam saepe architecto error corporis aliquam. Cum ipsam a consectetur aut sunt sint animi, pariatur corporis, eaque, deleniti cupiditate officia.</p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 mb-5" data-aos="fade-up" data-aos-delay="100">
            <a href="#"><img src="images/img_4.jpg" alt="Image" class="img-fluid"></a>
            <div class="p-4 bg-white">
              <span class="d-block text-secondary small text-uppercase">Jan 20th, 2019</span>
              <h2 class="h5 text-black mb-3"><a href="#">Art Gossip by Mike Charles</a></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias enim, ipsa exercitationem veniam quae sunt.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-5" data-aos="fade-up" data-aos-delay="200">
            <a href="#"><img src="images/img_2.jpg" alt="Image" class="img-fluid"></a>
            <div class="p-4 bg-white">
              <span class="d-block text-secondary small text-uppercase">Jan 20th, 2019</span>
              <h2 class="h5 text-black mb-3"><a href="#">Art Gossip by Mike Charles</a></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias enim, ipsa exercitationem veniam quae sunt.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-5" data-aos="fade-up" data-aos-delay="300">
            <a href="#"><img src="images/img_3.jpg" alt="Image" class="img-fluid"></a>
            <div class="p-4 bg-white">
              <span class="d-block text-secondary small text-uppercase">Jan 20th, 2019</span>
              <h2 class="h5 text-black mb-3"><a href="#">Art Gossip by Mike Charles</a></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias enim, ipsa exercitationem veniam quae sunt.</p>
            </div>
          </div>

        </div>

      </div>
    </div>

    
    <div class="site-section">
    <div class="container">
      <div class="row mb-5 justify-content-center">
        <div class="col-md-7">
          <div class="site-section-title text-center">
            <h2>Our Agents</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero magnam officiis ipsa eum pariatur labore fugit amet eaque iure vitae, repellendus laborum in modi reiciendis quis! Optio minima quibusdam, laboriosam.</p>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="col-md-6 col-lg-4 mb-5 mb-lg-5">
            <div class="team-member">

              <img src="images/person_1.jpg" alt="Image" class="img-fluid rounded mb-4">

              <div class="text">

                <h2 class="mb-2 font-weight-light text-black h4">Megan Smith</h2>
                <span class="d-block mb-3 text-white-opacity-05">Real Estate Agent</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi dolorem totam non quis facere blanditiis praesentium est. Totam atque corporis nisi, veniam non. Tempore cupiditate, vitae minus obcaecati provident beatae!</p>
                <p>
                  <a href="#" class="text-black p-2"><span class="icon-facebook"></span></a>
                  <a href="#" class="text-black p-2"><span class="icon-twitter"></span></a>
                  <a href="#" class="text-black p-2"><span class="icon-linkedin"></span></a>
                </p>
              </div>

            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-5 mb-lg-5">
            <div class="team-member">

              <img src="images/person_2.jpg" alt="Image" class="img-fluid rounded mb-4">

              <div class="text">

                <h2 class="mb-2 font-weight-light text-black h4">Brooke Cagle</h2>
                <span class="d-block mb-3 text-white-opacity-05">Real Estate Agent</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, cumque vitae voluptates culpa earum similique corrupti itaque veniam doloribus amet perspiciatis recusandae sequi nihil tenetur ad, modi quos id magni!</p>
                <p>
                  <a href="#" class="text-black p-2"><span class="icon-facebook"></span></a>
                  <a href="#" class="text-black p-2"><span class="icon-twitter"></span></a>
                  <a href="#" class="text-black p-2"><span class="icon-linkedin"></span></a>
                </p>
              </div>

            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-5 mb-lg-5">
            <div class="team-member">

              <img src="images/person_3.jpg" alt="Image" class="img-fluid rounded mb-4">

              <div class="text">

                <h2 class="mb-2 font-weight-light text-black h4">Philip Martin</h2>
                <span class="d-block mb-3 text-white-opacity-05">Real Estate Agent</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores illo iusto, inventore, iure dolorum officiis modi repellat nobis, praesentium perspiciatis, explicabo. Atque cupiditate, voluptates pariatur odit officia libero veniam quo.</p>
                <p>
                  <a href="#" class="text-black p-2"><span class="icon-facebook"></span></a>
                  <a href="#" class="text-black p-2"><span class="icon-twitter"></span></a>
                  <a href="#" class="text-black p-2"><span class="icon-linkedin"></span></a>
                </p>
              </div>

            </div>
          </div>

          

        </div>
    </div>-->
    </div>

<?php require_once("footer.php");?>